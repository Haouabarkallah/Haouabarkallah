# 👋 Hi, I'm Haoua Barkallah

## Full Stack Web Developer (Learning Journey)

> Building modern web applications with consistency and curiosity.

### 🌍 About Me
- 🎓 Computer Science graduate
- 📍 Cameroon
- 🌱 Learning: HTML, CSS, JavaScript, React, Node.js, Express, MongoDB, MySQL
- 🎯 Goal: Become a professional Full Stack Web Developer.

## 🛣️ Roadmap
- ✅ HTML & CSS
- ✅ Git & GitHub
- 🔄 JavaScript
- ⏳ React
- ⏳ Node.js + Express
- ⏳ MongoDB
- ⏳ Docker
- ⏳ AWS

## 🛠 Tech Stack
Frontend: HTML • CSS • JavaScript • React
Backend: Node.js • Express
Database: MongoDB • MySQL
Tools: Git • GitHub • VS Code • Docker • Postman

## 📊 GitHub Stats
Replace `USERNAME` with `Haouabarkallah`.

![Stats](https://github-readme-stats.vercel.app/api?username=Haouabarkallah&theme=tokyonight&show_icons=true)

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Haouabarkallah&layout=compact&theme=tokyonight)

![Streak](https://streak-stats.demolab.com?user=Haouabarkallah&theme=tokyonight)

## 🚀 Featured Projects
- BudgetNah
- Lygie
- Portfolio Website
- Task Manager
- REST API

## 🌐 Connect
- LinkedIn: https://www.linkedin.com/in/haoua-barkallah-matari
- Email: your.email@example.com
